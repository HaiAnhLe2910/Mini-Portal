package com.example.fhict_app;

import android.support.v7.widget.RecyclerView;
public class recyclerViewAdapter {
    private static final String tag="recyclerViewAdapter";
    public class ViewHolder extends RecyclerView.ViewHolder
}
